import React, { useState, useEffect, useRef } from 'react';
import {
  Linkedin, Mail, Github, DownloadIcon, User, Briefcase,
  Cpu, Code2, GraduationCap, Award, MapPin,
  Sun, Moon, Menu, X, Terminal,
  FileDownIcon
} from 'lucide-react';

import MBLogo from '../Logo'; // Import the logo
import { INITIAL_RESUME_DATA } from '../data/resumeData';
import { getThemeClasses } from '../utils/theme';
import ProjectDetailView from '../components/ProjectDetail';
import { AnimatePresence, motion } from 'framer-motion';
import { fadeIn, slideIn, staggerContainer, textVariant } from '../utils/motion';
import {
  SectionHeader, SkillCard, TimelineItem,
  ProjectCard, NavItem, Footer
} from '../components/UIComponents';

export default function PortfolioPage() {
  const [data, setData] = useState(INITIAL_RESUME_DATA);
  const [activeSection, setActiveSection] = useState('about');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [selectedProject, setSelectedProject] = useState(null);

  // THEME STATE: Default is false (Light Mode)
  const [isDark, setIsDark] = useState(false);
  const sidebarRef = useRef(null);

  const toggleTheme = () => setIsDark(!isDark);

  // Synchronize Body Background
  useEffect(() => {
    if (isDark) {
      document.body.style.backgroundColor = '#020617'; // slate-950
      document.body.style.color = '#e2e8f0'; // slate-200
    } else {
      document.body.style.backgroundColor = '#fdfbf7'; // beige paper
      document.body.style.color = '#292524'; // stone-800
    }
  }, [isDark]);

  // Dynamically update favicon based on theme
  useEffect(() => {
    const favicon = document.getElementById('favicon');
    if (favicon) {
      const bgColor = isDark ? '#1e293b' : '#e7e5e4'; // slate-800 or stone-200
      const textColor = isDark ? '#818cf8' : '#4f46e5'; // indigo-400 or indigo-600

      const svgString = `
        <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
          <rect width="100" height="100" rx="16" fill="${bgColor}" />
          <text x="50" y="50" dominant-baseline="central" text-anchor="middle" fill="${textColor}" font-size="50" font-family="Arial, sans-serif" font-weight="bold" dy="2">
            MB
          </text>
        </svg>
      `;

      // Encode the SVG string and set it as the href for the favicon
      const encodedSvg = encodeURIComponent(svgString);
      favicon.href = `data:image/svg+xml,${encodedSvg}`;
    }
  }, [isDark]);

  // SCROLL SPY LOGIC
  useEffect(() => {
    // If we are in project detail view, we don't spy on scroll
    if (selectedProject) return;

    const handleScroll = () => {
      const sections = ['about', 'experience', 'skills', 'projects', 'education'];

      let currentSection = activeSection;

      for (const section of sections) {
        const element = document.getElementById(section);
        if (element) {
          const rect = element.getBoundingClientRect();
          // Logic: visible if top is near viewport top OR inside the element
          if (rect.top >= 0 && rect.top <= 300) {
            currentSection = section;
            break;
          } else if (rect.top < 0 && rect.bottom > 100) {
            currentSection = section;
          }
        }
      }

      if (currentSection !== activeSection) {
        setActiveSection(currentSection);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [activeSection, selectedProject]);

  const theme = getThemeClasses(isDark);

  const scrollToSection = (id) => {
    if (selectedProject) {
      setSelectedProject(null);
      // Wait for re-render before scrolling
      setTimeout(() => {
        const element = document.getElementById(id);
        if (element) {
          element.scrollIntoView({ behavior: 'smooth' });
          setActiveSection(id);
        }
      }, 100);
    } else {
      const element = document.getElementById(id);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
        setActiveSection(id);
      }
    }
    setIsMobileMenuOpen(false);
  };

  const handleProjectSelect = (project) => {
    setSelectedProject(project);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className={`w-full ${theme.bg} ${theme.text} font-sans flex flex-col lg:flex-row transition-colors duration-300`}>

      {/* Mobile Header */}
      <div className={`lg:hidden fixed top-0 left-0 right-0 h-16 ${isDark ? 'bg-slate-950/90 border-slate-800' : 'bg-[#fdfbf7]/90 border-stone-200'} backdrop-blur-md border-b z-50 flex items-center justify-between px-4 shadow-sm transition-colors duration-300`}>
        <span className={`text-lg font-bold ${theme.textHeader}`}>Mohit
          {/* <span className="text-indigo-600">.Dev</span> */}
        </span>
        <div className="flex items-center gap-2">
          <button onClick={toggleTheme} className={`p-2 rounded-full ${isDark ? 'bg-slate-800 text-yellow-400' : 'bg-stone-200 text-stone-600'}`}>
            {isDark ? <Sun size={20} /> : <Moon size={20} />}
          </button>
          <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className={`${theme.textMuted} p-2`}>
            {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation Overlay */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, x: '100%' }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: '100%' }}
            transition={{ type: "tween", duration: 0.3 }}
            className={`fixed inset-0 z-40 ${theme.bg} pt-20 px-6 lg:hidden flex flex-col`}
          >
            <div className="flex flex-col gap-2">
              <NavItem section="about" active={activeSection} onClick={scrollToSection} icon={User} label="Profile Summary" isDark={isDark} />
              <NavItem section="experience" active={activeSection} onClick={scrollToSection} icon={Briefcase} label="Experience" isDark={isDark} />
              <NavItem section="skills" active={activeSection} onClick={scrollToSection} icon={Cpu} label="Tech Stack" isDark={isDark} />
              <NavItem section="projects" active={activeSection} onClick={scrollToSection} icon={Code2} label="Projects" isDark={isDark} />
              <NavItem section="education" active={activeSection} onClick={scrollToSection} icon={GraduationCap} label="Education" isDark={isDark} />
            </div>

            <div className={`mt-auto mb-8 pt-6 border-t ${theme.sidebarBorder}`}>
              <div className="flex gap-6 justify-center">
                <a href={data.profile.linkedin} target="_blank" rel="noreferrer" className={`${theme.textMuted} hover:text-indigo-600 hover:scale-110 transition-all`}><Linkedin size={24} /></a>
                <a href={`mailto:${data.profile.email}`} className={`${theme.textMuted} hover:text-indigo-600 hover:scale-110 transition-all`}><Mail size={24} /></a>
                <a href={data.profile.github} target="_blank" rel="noreferrer" className={`${theme.textMuted} hover:text-indigo-600 hover:scale-110 transition-all`}><Github size={24} /></a>
                <a href={data.profile.resume} target="_blank" rel="noreferrer" className={`${theme.textMuted} hover:text-indigo-600 hover:scale-110 transition-all`}><FileDownIcon size={24} /></a>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Sidebar (Desktop) */}
      <aside ref={sidebarRef} className={`hidden lg:flex flex-col w-80 sticky top-4 self-start h-[calc(100vh-2rem)] rounded-2xl border ${theme.sidebarBorder} ${theme.sidebarBg} backdrop-blur-sm transition-colors duration-300`}>
        <div className="mb-10 px-4 pt-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <MBLogo isDark={isDark} size={40} />
            <div>
              <h1 className={`text-xl font-bold ${theme.textHeader} tracking-tight`}>
                Mohit Bellwani
              </h1>
              <p className={`${theme.textMuted} text-xs mt-1 font-mono uppercase tracking-widest`}>Application & Support Engineer</p>
            </div>
          </div>
          <button
            onClick={toggleTheme}
            className={`p-3 rounded-full transition-all ${isDark ? 'bg-slate-800 text-yellow-400 hover:bg-slate-700' : 'bg-stone-100 text-stone-500 hover:bg-stone-200'}`}
            title="Toggle Dark Mode"
          >
            {isDark ? <Sun size={18} /> : <Moon size={18} />}
          </button>
        </div>

        <nav className="flex-1 flex flex-col gap-2 px-4 overflow-y-auto">
          <NavItem section="about" active={!selectedProject && activeSection === 'about' ? 'about' : ''} onClick={scrollToSection} icon={User} label="Profile Summary" isDark={isDark} />
          <NavItem section="experience" active={!selectedProject && activeSection === 'experience' ? 'experience' : ''} onClick={scrollToSection} icon={Briefcase} label="Experience" isDark={isDark} />
          <NavItem section="skills" active={!selectedProject && activeSection === 'skills' ? 'skills' : ''} onClick={scrollToSection} icon={Cpu} label="Tech Stack" isDark={isDark} />
          <NavItem section="projects" active={selectedProject || activeSection === 'projects' ? 'projects' : ''} onClick={scrollToSection} icon={Code2} label="Projects" isDark={isDark} />
          <NavItem section="education" active={!selectedProject && activeSection === 'education' ? 'education' : ''} onClick={scrollToSection} icon={GraduationCap} label="Education" isDark={isDark} />
        </nav>

        <div className={`mt-auto pt-6 pb-6 border-t ${theme.sidebarBorder} px-4`}>
          <div className="flex gap-4 justify-center">
            <a href={data.profile.linkedin} target="_blank" rel="noreferrer" className={`${theme.textMuted} hover:text-indigo-600 hover:scale-110 transition-all`}><Linkedin size={20} /></a>
            <a href={`mailto:${data.profile.email}`} className={`${theme.textMuted} hover:text-indigo-600 hover:scale-110 transition-all`}><Mail size={20} /></a>
            <a href={data.profile.github} target="_blank" rel="noreferrer" className={`${theme.textMuted} hover:text-indigo-600 hover:scale-110 transition-all`}><Github size={20} /></a>
            <a href={data.profile.resume} target="_blank" rel="noreferrer" className={`${theme.textMuted} hover:text-indigo-600 hover:scale-110 transition-all`}><FileDownIcon size={20} /></a>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 p-6 lg:p-12 pt-24 max-w-5xl mx-auto w-full flex flex-col lg:overflow-y-auto">

        <div className="flex-1">
          {selectedProject ? (
            <ProjectDetailView project={selectedProject} onBack={() => setSelectedProject(null)} isDark={isDark} />
          ) : (
            <>
              {/* Hero / About Section */}
              <motion.section
                id="about"
                className="mb-32 scroll-mt-24"
                variants={staggerContainer()}
                initial="hidden"
                whileInView="show"
                viewport={{ once: true, amount: 0.25 }}
              >
                <motion.div variants={fadeIn("up", "tween", 0.2, 1)} className={`${theme.cardBg} p-8 rounded-2xl border ${theme.cardBorder} shadow-sm mb-10 transition-colors duration-300`}>
                  <h1 className={`text-4xl lg:text-5xl font-bold ${theme.textHeader} mb-4`}>
                    Hello, I'm <span className="text-indigo-600">Mohit</span>
                  </h1>
                  <p className={`text-xl ${theme.textMuted} max-w-2xl leading-relaxed`}>
                    {data.profile.tagline}
                  </p>
                  <div className={`flex flex-wrap gap-4 mt-6 text-sm font-medium ${theme.textMuted} justify-center items-center`}>
                    <span className="flex items-center gap-1.5"><MapPin size={16} className="text-indigo-600" /> {data.profile.location}</span>
                    <span className="flex items-center gap-1.5"><Mail size={16} className="text-indigo-600" /> {data.profile.email}</span>
                  </div>
                </motion.div>

                <motion.div variants={textVariant(1.1)} className={`prose max-w-none ${theme.textMuted} leading-7 text-lg text-justify`}>
                  <p>{data.profile.bio}</p>
                </motion.div>
              </motion.section>

              {/* Experience Section */}
              <motion.section
                id="experience"
                className="mb-32 scroll-mt-24"
                variants={staggerContainer()}
                initial="hidden"
                whileInView="show"
                viewport={{ once: true, amount: 0.1 }}
              >
                <SectionHeader title="Work Experience" icon={Briefcase} isDark={isDark} />
                <div className={`${theme.cardBg} p-8 rounded-2xl border ${theme.cardBorder} shadow-sm transition-colors duration-300 relative overflow-hidden`}>
                  {/* Decorative line for timeline can go here if needed */}
                  {data.experience.map((exp, index) => (
                    <TimelineItem
                      key={exp.id}
                      {...exp}
                      isLast={index === data.experience.length - 1}
                      isDark={isDark}
                      index={index}
                    />
                  ))}
                </div>
              </motion.section>

              {/* Skills Section */}
              <motion.section
                id="skills"
                className="mb-32 scroll-mt-24"
                variants={staggerContainer()}
                initial="hidden"
                whileInView="show"
                viewport={{ once: true, amount: 0.1 }}
              >
                <SectionHeader title="Technical Skills" icon={Terminal} isDark={isDark} />
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {data.skills.map((skillGroup, idx) => (
                    <SkillCard key={idx} {...skillGroup} isDark={isDark} index={idx} />
                  ))}
                </div>
              </motion.section>

              {/* Projects Section */}
              <motion.section
                id="projects"
                className="mb-32 scroll-mt-24"
                variants={staggerContainer()}
                initial="hidden"
                whileInView="show"
                viewport={{ once: true, amount: 0.1 }}
              >
                <SectionHeader title="Featured Projects" icon={Code2} isDark={isDark} />
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {data.projects.map((project, index) => (
                    <ProjectCard key={project.id} project={project} onSelect={handleProjectSelect} isDark={isDark} index={index} />
                  ))}
                </div>
              </motion.section>

              {/* Education & Certifications */}
              <motion.section
                id="education"
                className="mb-32 scroll-mt-24"
                variants={staggerContainer()}
                initial="hidden"
                whileInView="show"
                viewport={{ once: true, amount: 0.1 }}
              >
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">

                  {/* Education Column */}
                  <motion.div variants={fadeIn("up", "tween", 0.2, 1)}>
                    <SectionHeader title="Education" icon={GraduationCap} isDark={isDark} />
                    <div className="space-y-8">
                      {data.education.map((edu, idx) => (
                        <div key={idx} className={`${theme.cardBg} p-6 rounded-xl border ${theme.cardBorder} shadow-sm transition-colors duration-300`}>
                          <div className="flex justify-between items-start mb-2">
                            <h3 className={`text-lg font-bold ${theme.textHeader}`}>{edu.degree}</h3>
                            <span className={`text-xs font-mono ${theme.textMuted} border ${theme.cardBorder} ${theme.bg} px-2 py-1 rounded`}>{edu.year}</span>
                          </div>
                          <p className={`${theme.primaryText} text-sm mb-2`}>{edu.school}</p>
                          <p className={`${theme.textMuted} text-xs italic`}>{edu.detail}</p>
                        </div>
                      ))}
                    </div>
                  </motion.div>

                  {/* Certifications Column */}
                  <motion.div variants={fadeIn("up", "tween", 0.4, 1)}>
                    <SectionHeader title="Certifications" icon={Award} isDark={isDark} />
                    <div className="space-y-4">
                      {data.certifications.map((cert, idx) => (
                        <div key={idx} className={`flex gap-4 items-start p-4 rounded-xl ${theme.cardBg} border ${theme.cardBorder} ${theme.cardHoverBorder} transition-colors shadow-sm`}>
                          <div className={`mt-1 p-2 ${theme.primaryBgLight} rounded-full ${theme.primaryText}`}>
                            <Award size={16} />
                          </div>
                          <div>
                            <h4 className={`font-semibold ${theme.textHeader} text-sm`}>{cert.name}</h4>
                            <div className={`flex gap-2 mt-1 text-xs ${theme.textMuted}`}>
                              <span>{cert.issuer}</span>
                              <span>•</span>
                              <span>{cert.year}</span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </motion.div>

                </div>
              </motion.section>
            </>
          )}
        </div>

        {/* Footer */}
        <Footer isDark={isDark} />

      </main>
    </div>
  );
}